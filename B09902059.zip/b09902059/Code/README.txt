XOR_revenge: 
	步驟放在solve.ipynb 裡面，需要另外在sage 下執行。
Other：
	每一題資料夾內都有solve.py 的檔案，執行方式 python solve.py 。
	
