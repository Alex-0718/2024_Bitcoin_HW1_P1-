mkdir videos

wget 'https://github.com/Alex-0718/2024_Bitcoin_HW1_P1/blob/main/Bitcoin_HW0_1.mp4' -O ./videos/Bitcoin_HW0_1.mp4
wget 'https://github.com/Alex-0718/2024_Bitcoin_HW1_P1/blob/main/Bitcoin_HW0_2.mp4' -O ./videos/Bitcoin_HW0_2.mp4